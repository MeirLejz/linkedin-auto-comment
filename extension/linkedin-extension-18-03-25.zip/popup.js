document.addEventListener('DOMContentLoaded', function() {
  // Nothing needed here now that API key functionality has been removed
  // The popup will simply display the static information from the HTML
});